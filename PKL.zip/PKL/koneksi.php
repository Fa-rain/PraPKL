<?php
$server = "localhost";
$username = "root";
$password = "";
$database = "pkl_1";

$koneksi = mysqli_connect($server, $username, $password, $database);

// if($koneksi){
//     echo "berhasil";
// }else{
//     echo "gagal";
// }
// ?>
